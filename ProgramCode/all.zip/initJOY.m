function [ joyID ] = initJOY( )
% Initialise the joystick

joyID = vrjoystick(1);

end

