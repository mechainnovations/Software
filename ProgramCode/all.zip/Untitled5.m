%calc point;

%3 lengths

AB = 0.6093;
BC = 1.9182;
BD = 2.6402;

ABs = AB^2;
