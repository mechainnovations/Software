% Testing timer resolution

tic;

a = 10;
b = 15;

while toc < 0.1
    ;
end

l = toc