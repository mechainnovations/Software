% Initial bucket position setup

[boomAngle, stickAngle, bucketAngle, slewAngle] = getAngles();
I = Calc_PositionI(boomAngle, stickAngle);